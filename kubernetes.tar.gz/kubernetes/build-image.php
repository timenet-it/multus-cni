#!//usr/bin/php
<?php
$prefix = "evox";
$registry = "registry.penteres.it:5000/$prefix-";
if(!isset($argv[2]) || $argv[2] == ''){
    $tag = "";
} else $tag = "";
if(!isset($argv[1]) || $argv[1] == ''){
    echo "image not set!\n usage: build-image.php <projectname>\n";
} else {
    $script  = "cd ../\n";
    $script .= "cd ".$argv[1]."\n";
    $script .= "docker build -t ".$registry.$argv[1]." .\n";
    echo shell_exec($script);
    echo shell_exec("docker push ".$registry.$argv[1]);
}
?>