# HOW TO RUN KUBERNETES WITH MULTI / MACVLAN / WEAVE / KUBE-DNS

First of all you have to create a kubernetes running cluster with `NO` CNI network (so `kubectl get nodes` should return "Not Ready" in running state)

Then follow those steps: 
```
# Connect via ssh to master node
# Copy kubectl config
mkdir -p $HOME/.kube
cp /etc/kubernetes/admin.conf $HOME/.kube/config
echo "export KUBECONFIG=$HOME/.kube/config" >> $HOME/.bash_profile

# install weave network (we need control containers)
kubectl apply -f /root/git/evox-compose/kubernetes/cni/weave-kube-1.6

# then create TPR network
kubectl create -f https://raw.githubusercontent.com/timenet-it/multus-cni/master/tprnetwork.yaml
kubectl get thirdpartyresource
sleep 10
kubectl create -f /root/git/evox-compose/kubernetes/cni/macvlan-network-private.yaml
kubectl create -f /root/git/evox-compose/kubernetes/cni/network-kube-router.yaml
sleep 1
kubectl get network

# ---------- MULTUS TIME (on every node) ----------
cd /etc/cni/net.d/
wget https://raw.githubusercontent.com/timenet-it/multus-cni/master/multus-cni.conf

# NOW copy master:/etc/kubernetes/admin conf in every node:/etc/kubernetes/


# check another time that EVERYWHERE in /etc/cni/net.d/ you can find ONLY multus-cni.conf
# ------------------------------------------------------------

```

now if everything is ok you should be able to see all your nodes online

```
root@kube-master ~# kubectl get nodes
NAME                        STATUS    AGE       VERSION
kube-master.cloud.evox.it   Ready     1d        v1.7.4
kube01.cloud.evox.it        Ready     1d        v1.7.4
kube02.cloud.evox.it        Ready     1d        v1.7.4
```


ok, let's start your first multi-network pod

```
cd kubernetes/cni/
kubectl create -f pod-multi-network.yaml
#ok, see if is created:

root@kube-master ~/g/e/k/cni# kubectl get pods -o wide --all-namespaces
NAMESPACE     NAME                                                READY     STATUS    RESTARTS   AGE       IP              NODE
default       multus-multi-net-poc                                1/1       Running   1          18m       10.38.0.83      kube02.cloud.evox.it
```

`AWESOME`!

Let's find every net interface: 

```
root@kube-master ~/g/e/k/cni# kubectl exec -it multus-multi-net-poc sh
/ # ifconfig
eth0      Link encap:Ethernet  HWaddr 96:AB:80:E0:52:E9
          inet addr:10.38.0.83  Bcast:0.0.0.0  Mask:255.240.0.0
          UP BROADCAST RUNNING MULTICAST  MTU:1376  Metric:1
          RX packets:44 errors:0 dropped:0 overruns:0 frame:0
          TX packets:1 errors:0 dropped:0 overruns:0 carrier:0
          collisions:0 txqueuelen:0
          RX bytes:3256 (3.1 KiB)  TX bytes:42 (42.0 B)

lo        Link encap:Local Loopback
          inet addr:127.0.0.1  Mask:255.0.0.0
          UP LOOPBACK RUNNING  MTU:65536  Metric:1
          RX packets:0 errors:0 dropped:0 overruns:0 frame:0
          TX packets:0 errors:0 dropped:0 overruns:0 carrier:0
          collisions:0 txqueuelen:1
          RX bytes:0 (0.0 B)  TX bytes:0 (0.0 B)

net0      Link encap:Ethernet  HWaddr 0A:58:AC:10:CA:67
          inet addr:172.16.202.103  Bcast:0.0.0.0  Mask:255.255.0.0
          UP BROADCAST RUNNING MULTICAST  MTU:1500  Metric:1
          RX packets:924 errors:0 dropped:0 overruns:0 frame:0
          TX packets:0 errors:0 dropped:0 overruns:0 carrier:0
          collisions:0 txqueuelen:0
          RX bytes:65697 (64.1 KiB)  TX bytes:0 (0.0 B)

```

OK it's working

Time to restart kube-dns, actually he's looking for network but  auto-delegates in multus seems still not working :

delete deployment
```
kubectl delete deployment kube-dns -n=kube-system
```

create our kube-dns (made with annotations of network type)

```
kubectl create -f kube-dns-multi.yaml
```

you should see kube-dns up and running:

```
kube-system   kube-dns-351169436-cpnnd                            3/3       Running   6          14m       10.40.0.165     kube01.cloud.evox.it
```

Ok, still the end

In MACVLAN we specify a "network" object `kubectl get networks` BUT if you start PODs with macvlan driver you'll have duplicated ip's !! (`ARGH!`)

How could this be avoidable ? 


create a NFS server in master node: 
```
apt-get install nfs-kernel-server
cat << EOF >> /etc/exports
/var/lib/cni/networks 172.16.201.0/24(rw,no_root_squash)
EOF

systemctl restart nfs-kernel-server
```
*** IN ALL CLIENTS ***
install nfs client and mount directory:

```
apt-get install -y nfs-common
mount 172.16.201.20:/var/lib/cni/networks /var/lib/cni/networks
```

Don't forget to add to fstab! 
