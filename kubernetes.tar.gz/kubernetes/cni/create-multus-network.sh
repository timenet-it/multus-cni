#!/bin/bash
rm /etc/cni/net.d/*
kubectl delete -f https://raw.githubusercontent.com/timenet-it/multus-cni/master/tprnetwork.yaml
kubectl create -f https://raw.githubusercontent.com/timenet-it/multus-cni/master/tprnetwork.yaml
kubectl get thirdpartyresource
sleep 10
kubectl -f https://raw.githubusercontent.com/timenet-it/multus-cni/master/weave-network.yaml
kubectl create -f https://raw.githubusercontent.com/timenet-it/multus-cni/master/weave-network.yaml
kubectl delete -f https://raw.githubusercontent.com/timenet-it/multus-cni/master/macvlan-network.yaml
kubectl create -f https://raw.githubusercontent.com/timenet-it/multus-cni/master/macvlan-network.yaml
sleep 1
kubectl get network
# --------- MULTUS ---------------
wget https://raw.githubusercontent.com/timenet-it/multus-cni/master/multus-cni.conf
cp multus-cni.conf /etc/cni/net.dcreate /
wget https://raw.githubusercontent.com/timenet-it/multus-cni/master/multus
cp multus-cni.conf /etc/cni/net.d/

